# Name: Maninderpreet Singh Puri
# Student number: 20494381

# Configuring working directory
setwd("C:/Users/Sazee/Desktop/BUS5CA/Assignment 2")

#Adding libraries
install.packages(readr)
library(readr)

# Loading the dataset.
demog <- read.csv(file="demographics_TRAIN.csv", header=TRUE, sep=",")
behav <- read.csv(file="behavioural_TRAIN.csv", header=TRUE, sep=",")

# Cross clustering with subscribed
a <- table(demog$X_SEGMENT_, behav$X_SEGMENT_, behav$Subscribed)
print(a)

# Cross clustering
b <- table(demog$X_SEGMENT_, behav$X_SEGMENT_)
print(b)

# calculate Lift
c=0
for (i in 1:35)
{
  c[i] = a[i + 35] / b [i] 
}

d <- matrix(c, nrow = 7, ncol = 5, byrow= FALSE, dimnames = list(c("Segment 1", "Segment 2", "Segment 3", "Segment 4", "Segment 5", "Segment 6", "Segment 7"), c("Segment 1", "Segment 2", "Segment 3", "Segment 4", "Segment 5")))
print(d)
